GitPython is a python library used to interact with Git repositories


