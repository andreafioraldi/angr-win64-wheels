DEBUG = True

#
# Observation point types
#
OP_BEFORE = 0
OP_AFTER = 1
