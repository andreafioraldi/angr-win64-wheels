
from ..libc.scanf import scanf

class __isoc99_scanf(scanf):
    pass
