class ANAError(Exception):
    pass
